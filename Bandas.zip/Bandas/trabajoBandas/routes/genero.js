const express = require('express');
const bandas = require('../db');
const router = express.Router();


router.get('/genero', function(req, res) {
    res.send(bandas.lista.genero);
  });

module.exports = router;
var express = require('express');
const bandas = require('../db');
var router = express.Router();


router.get('/', function(req, res) {
  res.send(bandas.lista);
});

module.exports = router;

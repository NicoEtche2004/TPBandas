const express = require('express');
const bandas = require('../db');
const router = express.Router();


router.get('/id:id', function(req, res) {
    res.send(bandas.lista.id);
  });

module.exports = router;
const lista = require('../db/index')
const controller = {
lista: function (req,res) {
    res.render(lista)
},
detalle: function (req,res) {
    const id = req.params.id
        for (let i = 0; i < lista.length; i++) {
            if (Number(id)===Number(lista[i].id)) {
                res.send(`${lista[i].nombre},${lista[i].integrantes},${lista[i].genero},${lista[i].topCanciones},${lista[i].cover},${lista[i].video}`)
            }
        }
        res.send('no se encontro nada')
},
genero: function (req,res) {
    const genero = req.params.genero
        for (let i = 0; i < lista.length; i++) {
            if ((genero)===(lista[i].genero)) {
                res.send(`${lista[i].nombre},${lista[i].integrantes},${lista[i].topCanciones},${lista[i].cover},${lista[i].video}`)
            }
        }
        res.send('no se encontro nada')
}
}

module.exports = controller